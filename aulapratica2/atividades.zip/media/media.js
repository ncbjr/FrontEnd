function media() {
    let n1 = Number(window.prompt('Digite um número: '))
    let n2 = Number(window.prompt('Digite outro número: '))
    let media = (n1 + n2)/2
    let res = document.querySelector('section#saida')
    res.innerHTML = `<p>A média é <strong>${media}</strong>.</p>`
}