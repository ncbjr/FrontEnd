function inverte() {
    let n = Number(window.prompt('Digite um número: '))

    valor = n.toString().split("");
    inverso = valor.reverse().join("");

    let res = document.querySelector('section#saida')
    res.innerHTML = `<p>O original é <strong>${n}</strong> e o inverso é <strong>${inverso}</strong>.</p>`
}