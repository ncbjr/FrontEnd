function calcularetorno() {
    let c = Number(window.prompt('Qual é o capital inicial?'))
    let i = Number(window.prompt('Qual é a taxa de juros em percentual?'))
    let t = Number(window.prompt('Quantos períodos o investimento terá?'))
    let retorno = Number(c*((1+(i/100))**t))

    let res = document.querySelector('section#saida')
    res.innerHTML = `<p>O capital inicial é <strong>${c}</strong>, a taxa de juros é <strong>${i}%</strong>, e o investimento permanecerá por <strong>${t}</strong> períodos, o retorno total será de <strong>${retorno}</strong>.</p>`
}